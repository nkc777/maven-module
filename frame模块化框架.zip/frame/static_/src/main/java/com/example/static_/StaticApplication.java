package com.example.static_;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class StaticApplication {

//    public static void main(String[] args) {
//        SpringApplication.run(StaticApplication.class, args);
//    }

}

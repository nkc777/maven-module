/**
 * @author NiKaiChuang
 * @version 2019/9/27 10:27
 */
public class out {
    public void outMethod(){};
}

package onePack;

/**
 * @author NiKaiChuang
 * @version 2019/9/27 10:29
 */
public class one {
    public void one(){};
}

package com.example.utils.utils;

/**
 * @author NiKaiChuang
 * @version 2019/9/26 10:11
 */
public class DBHelper {
    public static void getDB(){

    }
}

package com.example.common;

import onePack.*;

/**
 * @author NiKaiChuang
 * @version 2019/9/26 16:10
 */
public class common {
    public static void getCommon(){
        one one = new one();
    }
    public static String getString(){
        return "web";
    }
}

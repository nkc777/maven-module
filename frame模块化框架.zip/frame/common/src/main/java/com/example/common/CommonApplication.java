package com.example.common;

import com.example.utils.utils.DBHelper;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class CommonApplication {

//	public static void main(String[] args) {
//		SpringApplication.run(CommonApplication.class, args);
//		DBHelper dbHelper = new DBHelper();
//		DBHelper.getDB();
//	}

}
